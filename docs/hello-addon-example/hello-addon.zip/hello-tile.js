class TwHelloGreeting extends HTMLElement {
  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this._settings = {};
  }
  set settings(val) {
    this._settings = val || {};
    this.render();
  }
  connectedCallback() { this.render(); }
  render() {
    const msg = this._settings.message;
    this.shadowRoot.innerHTML = `
      <style>
        :host { display: flex; width: 100%; height: 100%; align-items: center; justify-content: center;
                padding: var(--tw-tile-padding); color: var(--tw-text); font-family: var(--tw-font-family); }
      </style>
      <div>${msg ? msg : 'Needs setup'}</div>
    `;
  }
}
if (!customElements.get('tw-hello-greeting')) {
  customElements.define('tw-hello-greeting', TwHelloGreeting);
}
